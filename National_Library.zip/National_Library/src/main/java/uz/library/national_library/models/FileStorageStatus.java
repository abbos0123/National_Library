package uz.library.national_library.models;

public enum FileStorageStatus {
    ACTIVE, DRAFT
}
